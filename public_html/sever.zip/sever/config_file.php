<?php
 
//Define your host here.
$host_name = "localhost";
 
//Define your database name here.
$database_name = "esoildat_soil_data_banks";
 
//Define your database username here.
$host_user = "esoildat_bill";
 
//Define your database password here.
$host_password = "esoildat_soil_data_banks";